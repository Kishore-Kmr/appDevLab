<?php

// Set error reporting for debugging (optional)
ini_set('display_errors', 1);
ini_set('error_reporting', E_ALL);

// Define upload directory and allowed file extensions
$upload_dir = 'uploads/'; // Create this directory if it doesn't exist
$allowed_extensions = array('pdf', 'docx', 'jpg', 'jpeg', 'png');

// Validate and process uploaded file
if (isset($_FILES['uploaded_file'])) {
    $file_name = $_FILES['uploaded_file']['name'];
    $file_size = $_FILES['uploaded_file']['size'];
    $file_tmp_name = $_FILES['uploaded_file']['tmp_name'];
    $file_type = $_FILES['uploaded_file']['type'];
    $file_ext = strtolower(end(explode('.', $file_name)));

    // Check for errors
    if ($_FILES['uploaded_file']['error'] === 0) {
        // Check file size limit (adjust limit as needed)
        if ($file_size <= 1048576) {  // 1 MB
            // Check allowed extensions
            if (in_array($file_ext, $allowed_extensions)) {
                // Generate a unique filename
                $new_file_name = uniqid('', true) . '.' . $file_ext;
                // Move uploaded file to the upload directory
                if (move_uploaded_file($file_tmp_name, $upload_dir . $new_file_name)) {
                    echo "File uploaded successfully!"; // Success message
                } else {
                    echo "Error moving uploaded file.";
                }
            } else {
                echo "Invalid file extension.";
            }
        } else {
            echo "File size exceeds limit.";
        }
    } else {
        echo "Upload error: " . $_FILES['uploaded_file']['error'];
    }
} else {
    echo "No file uploaded.";
}

// **New: Code to view uploaded files**
$files = scandir($upload_dir);  // Get a list of files in the upload directory
$uploaded_files = array_slice($files, 2);  // Remove '.' and '..' entries

if (!empty($uploaded_files)) {
    echo "<h2>Uploaded Files</h2>";
    echo "<ul>";
    foreach ($uploaded_files as $file) {
        $file_path = $upload_dir . $file;  // Construct the full file path
        // Check if it's an image file (adjust based on your needs)
        if (in_array(mime_content_type($file_path), array('image/jpeg', 'image/png', 'image/gif'))) {
            echo "<li><a href='$file_path' target='_blank'><img src='$file_path' alt='$file' width='100' height='100'></a></li>";
        } else {
            echo "<li><a href='$file_path' target='_blank'>$file</a></li>";
        }
    }
    echo "</ul>";
} else {
    echo "No files uploaded yet.";
}

?>
