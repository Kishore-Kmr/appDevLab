<!DOCTYPE html>
<html>
<head>
    <title>File Upload App</title>
</head>
<body>
    <h1>Upload Your File</h1>
    <form action="upload.php" method="post" enctype="multipart/form-data">
        <input type="file" name="uploaded_file" accept=".pdf,.docx,.jpg,.png, .jpeg" required>
        <br>
        <button type="submit">Upload</button>
    </form>
</body>
</html>
